8/19/2024

Hello! My name is Alex Wilmes, and I am a Computer Science student at the University of Montana. I thought it would be a fun and beneficial learning experience to create a Tic-Tac-Toe game using Python and PyGame.

I wanted to make this project a true learning experience. During development, I refrained from using AI assistance and only utilized AI when I was really stuck. GitHub Copilot and ChatGPT were the AI services I used when making this project.

All images and sounds used in this project are free-to-use. All sounds were downloaded from free-to-use websites, and all images were either created by me using free-to-use websites or downloaded from free-to-use websites.  

Websites, images, and sounds used for this project:

background.png, bluewinscreen.png, redwinscreen.png, and nowinnerscreen.png were all drawn by me using pixilart.com,






Feel free to reach out with any suggestions or questions!

Contact: alexwilmes55@gmail.com

